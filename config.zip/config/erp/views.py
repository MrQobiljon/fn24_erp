from django.shortcuts import render
from django.forms import model_to_dict

from rest_framework.views import APIView
from rest_framework.request import Request
from rest_framework.response import Response

from .models import Student
from .serializers import StudentSerializer

# Create your views here.


class StudentApiView(APIView):
    def get(self, request: Request, pk=None):
        if pk:
            student = Student.objects.get(pk=pk)
            return Response(StudentSerializer(student).data)

        students = Student.objects.all()
        return Response(StudentSerializer(students, many=True).data)

