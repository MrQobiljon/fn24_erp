from rest_framework import serializers


class StudentSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    group_id = serializers.IntegerField()
    full_name = serializers.CharField(max_length=64)
    age = serializers.IntegerField(min_value=5, max_value=100)
    address = serializers.CharField(max_length=255)
    phone_number = serializers.CharField(max_length=13)
    email = serializers.EmailField()